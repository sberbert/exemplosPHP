<?php
    echo "Olá, mundo!";